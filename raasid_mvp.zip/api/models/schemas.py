from pydantic import BaseModel

class DecisionInput(BaseModel):
    frame: int
    final_decision: str
    certainty_score: float
    VAR_review: bool

class VAROverrideInput(BaseModel):
    frame: int
    override_decision: str
