from fastapi import APIRouter
from pydantic import BaseModel
import json, os, logging
from api.models.schemas import DecisionInput, VAROverrideInput


router = APIRouter()

DECISION_LOGS_FILE = "data/decision_logs.json"
os.makedirs("data", exist_ok=True)

# Load or initialize decision log
if os.path.exists(DECISION_LOGS_FILE):
    with open(DECISION_LOGS_FILE, "r") as f:
        try:
            decision_logs = json.load(f)
            if not isinstance(decision_logs, list):
                decision_logs = []
        except json.JSONDecodeError:
            decision_logs = []
else:
    decision_logs = []

def save_decision_log():
    with open(DECISION_LOGS_FILE, "w") as f:
        json.dump(decision_logs, f, indent=4)
    logging.info("Saved decision log to file.")

# Request models
class DecisionInput(BaseModel):
    frame: int
    final_decision: str
    certainty_score: float
    VAR_review: bool

class VAROverrideInput(BaseModel):
    frame: int
    override_decision: str

# Endpoints
@router.post("/decision_making_ai")
def receive_decision(data: DecisionInput):
    logging.info(f"Decision Making AI: {data.dict()}")
    decision_logs.append(data.dict())
    save_decision_log()
    return {"status": "Success", "message": "Decision logged"}

@router.post("/var_review")
def apply_var_override(data: VAROverrideInput):
    for decision in decision_logs:
        if decision["frame"] == data.frame:
            decision["final_decision"] = data.override_decision
            decision["VAR_review"] = True
            save_decision_log()
            logging.info(f"VAR Override Applied: {data.override_decision}")
            return {"status": "Success", "message": "VAR override updated"}
    return {"status": "Error", "message": "Frame not found"}

@router.get("/decision_logs")
def get_logs():
    logging.info("Decision logs fetched")
    return decision_logs



